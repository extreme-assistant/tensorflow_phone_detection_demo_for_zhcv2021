import sys
import os

project_root = '/project/train/src_repo'
sys.path.append(os.path.join(project_root, 'tf-models/research'))
sys.path.append(os.path.join(project_root, 'tf-models/research/slim'))
